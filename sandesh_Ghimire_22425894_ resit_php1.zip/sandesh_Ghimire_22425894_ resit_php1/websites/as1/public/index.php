<?php
session_start();
require('databaseConnection.php');
require('providedHeader.php');
require('databaseQuery.php')
?>
<main>
<h1>Latest Listings</h1>
            <ul class="productList">
              <?php
             foreach($list4 as $data){
                $ID = $data['auctionID'];
                $name = $data['title'];
                $description = $data['description'];
                $categoryID = $data['categoryID'];
                $prepareCategory = $connecttion->prepare("SELECT name FROM `categories` where categoryID = '$categoryID'");
                $prepareCategory->execute();
                $list5 = $prepareCategory->fetchAll();
                foreach($list5 as $data){
                    $categoryOfAucs = $data['name'];
                }
                $prepareBid = $connecttion->prepare("SELECT bid FROM bids WHERE auctionID ='$ID'");
                $prepareBid->execute();
                $list12 = $prepareBid->fetchAll();
                $bidder = 0;
                foreach($list12 as $data){
                    $bidter = $data['bid'];
                    if ($bidter>$bidder){
                        $bidder = $bidter;
                    }
                }
              ?>
              <li><img src="product.png" alt="product name">
					<article>
					<h2><?php echo $name?></h2>
					<h3><?php echo $description?></h3>
					<p><?php echo $categoryOfAucs?></p>
                    <p class="price">Current bid: £<?php echo $bidder?></p>
                    <a href="auctionPages.php?auctionsId=<?php echo $ID ?>" class="more auctionLink">More &gt;&gt;</a>
					</article>
					</li>
                    <?php
                    }
                    ?>
            </ul>