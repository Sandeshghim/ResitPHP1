<?php

require('databaseConnection.php');
$prepareCategory = $connecttion->prepare("SELECT * FROM categories");
$prepareCategory->execute();
$list = $prepareCategory->fetchAll();
?>

<!-- this is for index page-->
<?php
$prepareAuc = $connecttion->prepare("SELECT * FROM `auctions` ORDER BY auctionID DESC LIMIT 10 ");
$prepareAuc->execute();
$list4 = $prepareAuc->fetchAll();
?>