<?php
session_start();
// Require the database connection and header files
require('databaseConnection.php');
require('providedHeader.php');

if(isset($_SESSION['username'])){
  // Check if the user has admin access rights
if($_SESSION['role'] == "admin"){
  // Check if a new category is being added
if(isset($_POST['addCategory'])){
    // Get the new category name from the form data
    $listedCategory = $_POST['listedCategory'];
     // Prepare and execute a SQL statement to insert the new category into the categories table
    $staementss = $connecttion->prepare("INSERT INTO `categories`(`name`) VALUES ('$listedCategory')");
    $staementss->execute();
    }
?>
 <!-- Display the add category form -->
          <main>
            <form action="#" method="POST">
             <label>Category Name:</label>
             <input type="text" name ="listedCategory" required>
             <button class="addButton" name='addCategory'>ADD</button>
            </form>
 <?php
 // If a new category was successfully added, display a success message and a link to go back to the admin categories page
if(isset($_POST['addCategory'])){
echo 'successfully added';
echo '</br><button><a href="adminCategories.php">go Back</button></a>';
}
?>
          <main> 
            </html> 
<?php
}else{
  // If the user doesn't have admin access rights, display an error message
  echo 'You do not have admin access rights';
}
}else{
  // If the user isn't logged in, display an error message
  echo 'Unauthenciated.';
}
?>