<?php
session_start();
require 'providedHeader.php';
if (isset($_SESSION['username'])) {
    if ($_SESSION['role'] === "admin") {
        include_once('databaseConnection.php');
?>
        <form action="#" method="POST">
            <label><strong>Edit Category:</strong></label><br><br>
            <label for="changeCategory">Category name : </label>
            <input type="text" name="changeCategory" required><br>
            <button type="submit" name="submitBtn">Submit</button>
        </form>;
<?php
        if (isset($_POST['submitBtn'])) {
            $catID = $_GET['caI'];
            $changeCategory = ucwords($_POST['changeCategory']);
            $editC = $connecttion->prepare("UPDATE `categories` SET `name`='$changeCategory' WHERE category_id = '$catID'");
            $editC->execute();
            echo '<p>Category updated</p> <a href="index.php"><button>Go home</button></a>';
        }
    } else {
        echo 'Admin access denied';
    }
} else {
    echo 'Unauthenciated';
}
?>