<?php
session_start();
// Require the provided header
require 'providedHeader.php';
// observe if the user is logged in and has admin role
if (isset($_SESSION['username'])) {
    if ($_SESSION['role'] == "admin") {
        include_once('databaseConnection.php');
?>
<!-- Display a form to confirm if the user wants to delete the category -->
        <form action="deleteCategory.php?caI=" method="POST">
            <strong>Do you want to delete this category?</strong><br>
            <button type="submit" name="yes" value="Yes">Yes</button> <span>||</span> <a href="showCategories.php"><button>No</button></a>
        </form>
<?php
 // Check if the user has confirmed the deletion
        if (isset($_POST['yes'])) {
            // Get the category ID from the URL parameter
            $catID = $_GET['caL'];
            $deletec = $connecttion->prepare("DELETE FROM `categories` WHERE categoryID='".$catID."'");
            // Display a message and a link to go back to the index page
            // $deletec->execute();
            echo '<p>Changes has been made </p> <a href="index.php"><button>Go back</button></a>';
        }
    } else {
        echo 'Admin access denied';
    }
} else {
    echo 'Unauthenciated';
}
?>