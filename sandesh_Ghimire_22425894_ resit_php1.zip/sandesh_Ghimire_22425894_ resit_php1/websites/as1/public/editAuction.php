<?php
require 'providedHeader.php';
require 'databaseConnection.php';
require 'databaseQuery.php';

$auctionsID = $_GET['auctionsID'];

// getting the product data
$auctionI = $connecttion->query("SELECT `title`, `endDate`, `description` FROM `auctions` WHERE auctionID = $auctionsID;");
$auctionI->execute();
$fetchAuctionI = $auctionI->fetchAll();

foreach($fetchAuctionI as $fetchedResult){
    $prdtitle = $fetchedResult['title'];
    $prdendDate = $fetchedResult['endDate'];
    $prddescription = $fetchedResult['description'];
}
?>

<!-- edit acution form -->
<h2>Edit Auction Page</h2>

<form action="#" method="POST">
        <label for="productName">Prouct name</label>
        <input type="text" name="productName" value=<?php
        echo $prdtitle;
        ?>><br>
        <label for="productDesc">Description</label>
        <textarea name="productDesc" id="desc" cols="10" rows="6" maxlength="255"><?php
        echo $prddescription;
        ?></textarea>
        <label for="date">Date</label>
        <input type="date" name="date" value=<?php
        echo $prdendDate;
        ?>><br>
        <select name="categories">
          <?php
          foreach ($list as $categories) {
            $categoryName = $categories['name'];
            echo '<option value="' . $categoryName . '">' . $categoryName . '</option>';
          }
          ?>
        </select><br>
          <button type="submit" name="subm">Submit</button>
</form>

<?php
if(isset($_POST['subm'])){
    $prdtitlen = $_POST['productName'];
    $prddescn =$_POST['productDesc'];
    $prddaten = $_POST['date'];
    $prdcatn = $_POST['categories'];

    $updateAuctionQuery = $connecttion->query("UPDATE `auctions` SET `title`='$prdtitlen',`endDate`='$prddaten',`description`='$prddescn' WHERE auctionID = $auctionsID");
    $updateAuctionQuery->execute();
    echo "Auction Updated";
}
?>