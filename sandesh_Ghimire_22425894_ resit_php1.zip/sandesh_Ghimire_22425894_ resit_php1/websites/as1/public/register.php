<?php
require('databaseConnection.php');
require('providedHeader.php');
?>
<main>
<form  action="#" method="POST">
        <label>Username:</label>
        <input  type="text" name="user" required></br>
        <label>Email:</label>
        <input type="email" name="emails"  placeholder="sandesh205@gmail.com" required></br>
        <label for="password">Password:</label>
        <input type="password" name="code"  required></br>
        <input type="radio" name="userType" value="user"/> <label>user</label>
        <button name='buttonSubmit'>Register</button>
    </form>
    <?php
    if(isset($_POST['buttonSubmit'])){
        $user = $_POST['user'];
        $Emails = $_POST['emails'];
        $code =($_POST['code']);
        $accountType = $_POST['userType'];
        $staementss=$connecttion->prepare("INSERT INTO `registers`(`name`, `email`, `password`,`role`) VALUES ('$user','$Emails','$code','$accountType')");
        $staementss->execute();
        echo 'You have a user account.';
        }
        echo '</br><button><a href="index.php">back</button></a>';
    ?>
    <main>
        </html>