<?php
$connecttion = new PDO('mysql:dbname=assignment3;host=db', 'root', 'root',[PDO::ATTR_ERRMODE=> PDO::ERRMODE_EXCEPTION]);
?>