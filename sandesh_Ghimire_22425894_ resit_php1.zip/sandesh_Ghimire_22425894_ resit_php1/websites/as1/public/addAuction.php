<?php
session_start();
//Including required PHP files
require('databaseConnection.php');
require('providedHeader.php');
require('databaseQuery.php');
// Checking  if  the user is logged in or not
if (isset($_SESSION['username'])) {
?>
    <main>
        <form method="POST">
            <label> Auction Name:</label>
            <input type="text" name="inputTitle" required></br>
            <label>Description:</label>
            <input type="text" name="inputDescription" required></br>
            <label>Category Name:</label>
            <select name="selectCategory" required>
                <?php
                 // Retrieve category list from database and display as options in dropdown menu
                foreach ($list as $data) {
                    $categoryN = $data['name'];
                    $categoryI = $data['categoryID'];
                    echo '<option>' . $categoryN . '</option>';
                }
                ?>
            </select>
            </br><label>Last Date:</label>
            <input type="datetime" name="DateTime" value="2022-12-4 22:00:00" required>
            <button name='addAuction'>Add To Auction</button>
        </form>
        <div>
            <h1>List Of Auctions By You</h1>
            <?php
            //  for particular user auction
            $userID = $_SESSION['userID'];
                // Retrieve list of auctions created by current user from database
            $prepareAList = $connecttion->prepare("SELECT * FROM auctions WHERE registerID ='$userID'");
            $prepareAList->execute();
            $list3 = $prepareAList->fetchAll();
                // Displaying the list of auctions and include an "EDIT" link for each one
            foreach ($list3 as $data) {
                $auctionsList = $data['title'];
                $auctionsID = $data['auctionID'];
                echo '<li>' . $auctionsList . '</li><a href="editAuction.php?auctionsID='. $auctionsID .'">EDIT</a>';
            }
            ?>
        </div>
    <?php
    // Check if form to add a new auction has been submitted
    $userID = $_SESSION['userID'];
    if (isset($_POST['addAuction'])) {
        $inputTitle = $_POST['inputTitle'];
        $inputDescription = $_POST['inputDescription'];
        $selectCategory = $_POST['selectCategory'];
        $prepareCatID = $connecttion->prepare("SELECT categoryID FROM categories WHERE name='$selectCategory'");
        $prepareCatID->execute();
        $list2 = $prepareCatID->fetchAll();
        foreach ($list2 as $value) {
            $categID = $value['categoryID'];
        }
        $endTime = $_POST['DateTime'];
        
        // Retrieve category ID from database based on selected category name
        $prepareInsert = $connecttion->prepare("INSERT INTO `auctions`(`title`, `description`, `endDate`,`categoryID`, `registerID`) VALUES ('$inputTitle','$inputDescription','$endTime','$categID','$userID')");
        $prepareInsert->execute();
         // Display success message and link to return to homepage
        echo 'Auction has been added';
        echo '<a href=index.php>go back to home</a>';
    }
} else {
    //  display an error message when user isnot logged in
    echo 'Unauthenciated';
}

    ?>
    </main>

    </html>