<?php
session_start();
require('databaseConnection.php');
require('providedHeader.php');
require('databaseQuery.php');


if(isset($_SESSION['username'])){
if($_SESSION['role'] == "admin"){
?>
<main>
<div class="categories">
    <?php
    // Loop through each item in the $list array
    foreach($list as $data){
        // Get the category ID and name from the current item in the array
        $IDcategory = $data['categoryID'];
        $nCategory = $data['name'];
         // Display the category name as an HTML list item
        echo '<li>'.$nCategory.'</li>';
        //Display a link to edit the category, with the category ID as a parameter in the URL
        echo '<a href="editCategory.php?caI='.$IDcategory.'">edit<a>';
        // Display a link to delete the category, with the category ID as a parameter in the URL
        echo '<a href="deleteCategory.php?caI='.$IDcategory.'">delete<a>';
    }
    ?>
    <h2><a href="addCategories.php">ADD CATEGORY</a></h2>
</div>
</main>
</html>
<?php
}else{
    echo 'Admin access denied';
}
}else{
    echo 'Unauthenciated.';
}
?>