<?php
session_start();
require('providedHeader.php');
require('databaseConnection.php');
if(isset($_SESSION['username'])){
    //get current date
$cDates = date('d-m-y');
$em = $_SESSION['loginEmail'];
$ID = $_GET['auctionsId'];
$requiredEmail = $_SESSION['loginEmail'];  
//get user id  
$prepareID = $connecttion->prepare("SELECT registerID FROM registers WHERE email='$requiredEmail'");
$prepareID->execute();
$list1 = $prepareID->fetchAll();
$userID = $_SESSION['userID'];
foreach($list1 as $data){
$uID = $data['registerID'];
}
//add review 
if(isset($_POST['sub'])){
    $rWritten = $_POST['reviewtext'];
    $prepareRW = $connecttion->prepare("INSERT INTO `reviews`( `review`, `registerID`, `reviewDate`) VALUES ('$rWritten','$uID','$cDates')");
    $prepareRW->execute();
}
//place bid
if(isset($_POST['submis'])){
    $biddingA = $_POST['bid'];
    $prepareB= $connecttion->prepare("INSERT INTO `bids`( `bid`, `auctionID`, `registerID`) VALUES ('$biddingA','$ID','$uID')");
    $prepareB->execute();
}
//get hightest bid
$preapareGetB = $connecttion->prepare("SELECT bid FROM bids WHERE auctionID = '$ID'");
$preapareGetB->execute();
$list11 = $preapareGetB->fetchAll();
$bidder=0;
foreach($list11 as $data){
    $bidter = intval($data['bid']);
    if ($bidter>$bidder){
        $bidder = $bidter;
    }
}
?>
<main>
<hr />
<h1>Product Page</h1>
<article class="product">
     <img src="product.png" alt="product name">
        <?php
        //get product informrtion
        $prepareA = $connecttion->prepare("SELECT * FROM auctions WHERE auctionID = '$ID'");
        $prepareA->execute();
        $list6 = $prepareA->fetchAll();
        foreach($list6 as $data){
            $cIProduct = $data['categoryID'];
            $nProduct = $data['title'];
            $dProduct = $data['description'];
            $uProdcut = $data['registerID'];
            $duProduct = new DateTime($data['endDate']);
            $cDate =new DateTime();
            $tRemain = $cDate->diff($duProduct);
            $prepareC = $connecttion->prepare("SELECT name FROM categories WHERE categoryID = '$cIProduct'");
            $prepareC->execute();
            $list7 = $prepareC->fetchAll();
            foreach($list7 as $data){
                $nCategory = $data['name'];
            }
            $prepareR = $connecttion->prepare("SELECT name FROM registers WHERE registerID = '$uProdcut'");
            $prepareR->execute();
            $list8 = $prepareR->fetchAll();
            foreach($list8 as $data){
                $uName = $data['name'];
            }
        }
        ?>
        <section class="values">
            <h2><?php echo $nProduct?></h2>
            <h3><?php echo $nCategory?></h3>
            <p>Auction created by <a><?php echo $uName?></a></p>
            <p class="price">Current bid: £<?php echo $bidder?></p>
              <?php  echo'<time>Time left:'.$tRemain->format('%d day %H hour %i minute').'</time>';?>
            <form  action ="#" class="bid" method="POST">
                <input type="text" name="bid" placeholder="Enter bid amount" />
                <input name="submis" type="submit" value="Place bid" />
            </form>
            
        </section>
        <section>
        <p><?php echo $dProduct;?></p>
        </section>
        <section class="reviews">
            <ul>
           <?php
$prepareRe = $connecttion->prepare("SELECT * FROM reviews WHERE registerID = '$uID'");
$prepareRe->execute();
$list9 = $prepareRe->fetchAll();
foreach($list9 as $data){
    $R = $data['review'];
    $pD = $data['reviewDate'];
    $uID = $data['registerID'];
    $usName = $connecttion->prepare("SELECT name FROM registers WHERE registerID = '$uID'");
    $usName->execute();
    $list10 = $usName->fetchAll();
    foreach($list10 as $data){
        $nReviewer = $data['name'];
      echo'  <li><strong>'.$nReviewer.' said </strong>'.$R.'<em>'.$pD.'</em></li>';
    }
}?>
            </ul>

            <form  action= "#"method="POST">
                <label>Add your review</label> <textarea name="reviewtext"></textarea>
                <input type="submit" name="sub" value="Add Review" />
            </form>
        </section>
        </article>

        <hr />
</main>
<?php
}else{
    echo 'Unauthenciated.';
}
?>