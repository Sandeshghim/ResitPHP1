<?php
session_start();
require 'providedHeader.php';
include_once('databaseConnection.php');

?>

<!--  logout form -->
<form action="" method="POST">
    <label>Click here to </label>
    <button type="submit" name="logoutBtn" value="Logout">Logout</button>
</form>


<?php
// removing session value
if (isset($_POST['logoutBtn'])) {
    // unsetting all current running sessions 
    unset($_SESSION['username']);
    unset($_SESSION['role']);
    unset($_SESSION['userID']);
    unset($_SESSION['loginEmail']);
    echo 'You have been logged out';
}
?>