<?php
require('databaseConnection.php');
?>
<!DOCTYPE html>
<html>

<head>
	<!-- Setting the title of the page -->
	<title>ibuy Auctions</title>
	<!-- Linking to an external CSS file -->
	<link rel="stylesheet" href="ibuy.css" />
	<style>
			/* Defining the styles for  dropdown container */
		.dropdown {
			display: inline-block;/* Displaying the container as an inline block */
			position: relative; /* Setting the position of the container as relative */
		}
/* Defining the styles for the dropdown options */
		.dropdown-options {
			display: none;/* Initially hide the dropdown options */
			position: absolute;/* Setting the position of the dropdown options as absolute */
			overflow: auto; /* Adding scrolling to the dropdown options */
		}
/* Showing the dropdown options when the container is hovered */
		.dropdown:hover .dropdown-options {
			display: block;
		}
	</style>
</head>

<body>
	<header>
		<h1><a href="index.php"><span class="i">i</span><span class="b">b</span><span class="u">u</span><span class="y">y</span></a></h1>

		<form action="#">
			<input type="text" name="search" placeholder="Search for anything" />
			<input type="submit" name="submit" value="Search" />
		</form>
	</header>
	<nav>
		<ul>
			<?php
			require('databaseQuery.php');
			foreach ($list as $data) {
				$categoryN = $data['name'];
				$categoryI = $data['categoryID'];
				echo '<li><a class="categoryLink" href="categoryPages.php?categoryI=' . $categoryI . '">' . $categoryN . '</a></li>';
			}
			?>
		</ul>
	</nav>
	<div class="dropdown">
		<button>Options</button>
		<div class="dropdown-options">
			<a href="addAuction.php">Add auction</a>
			<a href="register.php">Register</a>
			<a href="login.php">login</a>
			<a href="logout.php">logout</a>
		</div>
	</div>
	<div class="dropdown">
		<button>Admin-Control</button>
		<div class="dropdown-options">
			<a href="adminCategories.php">Categories</a>
			<a href="addCategories.php">Add Category</a>
		</div>
	</div>
	<img src="banners/1.jpg" alt="Banner" />