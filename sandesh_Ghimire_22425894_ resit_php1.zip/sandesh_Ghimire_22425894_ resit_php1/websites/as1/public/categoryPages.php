<?php
// start session and include necessary files
session_start();
require('databaseConnection.php');
require('providedHeader.php');
require('databaseQuery.php');

// get category ID from GET request
$categoryID = $_GET['categoryI'];

// prepare and execute query to fetch all auctions with the specified category ID
$prepareC = $connecttion->prepare("SELECT * FROM auctions WHERE categoryID = '$categoryID'");
$prepareC->execute();
$list13 = $prepareC->fetchAll();

?>

<main>
  <h1>Latest Listings</h1>
  <ul class="productList">
    <?php
    // loop through each auction and display relevant information
    foreach($list13 as $data){
      $ID = $data['auctionID'];
      $name = $data['title'];
      $description = $data['description'];
      $categoryID = $data['categoryID'];

      // prepare and execute query to fetch category name for this auction
      $prepareCategory = $connecttion->prepare("SELECT name FROM `categories` where categoryID = '$categoryID'");
      $prepareCategory->execute();
      $list5 = $prepareCategory->fetchAll();
      foreach($list5 as $data){
        $categoryOfAucs = $data['name'];
      }

      // prepare and execute query to fetch highest bid for this auction
      $prepareBid = $connecttion->prepare("SELECT bid FROM bids WHERE auctionID ='$ID'");
      $prepareBid->execute();
      $list12 = $prepareBid->fetchAll();
      $bidder = 0;
      foreach($list12 as $data){
        $bidter = $data['bid'];
        if ($bidter > $bidder){
          $bidder = $bidter;
        }
      }

      // display auction information
      ?>
      <li>
        <img src="product.png" alt="product name">
        <article>
          <h2><?php echo $name ?></h2>
          <h3><?php echo $description ?></h3>
          <p><?php echo $categoryOfAucs ?></p>
          <p class="price">Current bid: £<?php echo $bidder ?></p>
          <a href="auctionPages.php?auctionsId=<?php echo $ID ?>&" class="more auctionLink">More &gt;&gt;</a>
        </article>
      </li>
    <?php
    }
    ?>
  </ul>
</main>
