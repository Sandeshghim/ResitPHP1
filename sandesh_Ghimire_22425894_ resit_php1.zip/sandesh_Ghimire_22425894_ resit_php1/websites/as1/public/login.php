<?php
// Starting  new session 
session_start();

// Require the database connection file
require('databaseConnection.php');

// Require the provided header file
require('providedHeader.php');
?>

<main>
    <form method="POST">
        <label>Email:</label>
        <input type="email" name="loginEmail">
        <label >Password:</label>
        <input type="password" name="loginPassword">
        <button name="loged">login</button>
    </form>

<?php
// observe if the 'loged' button has been pressed
if(isset($_POST['loged'])){
    // Get the email and password from the form
    $loginEmail = $_POST['loginEmail'];
    $loginPassword =$_POST['loginPassword'];

    // Prepare the SQL statement to check if the user exists
    $loggedin = $connecttion->prepare("SELECT * FROM `registers` WHERE email= :email AND password= :password");

    // Bind the values to the parameters in the SQL statement
    $values=[
        'email'=> $loginEmail,
        'password'=>$loginPassword
    ];
    $loggedin->execute($values);

    // Fetch all the rows returned by the SQL statement
    $logsData = $loggedin->fetchAll();

    // Loop through the rows and store the user's information in session variables
    foreach($logsData as $userInfo){
        $_SESSION['userID'] = $userInfo['registerID'];
        $_SESSION['username'] = $userInfo['name'];
        $_SESSION['role'] = $userInfo['role'];
        $_SESSION['loginEmail'] = $userInfo['email'];
    }

    // Check if any rows were returned by the SQL statement
    if($loggedin->rowCount()>0){
        // Set the 'log' session variable to true to indicate that the user is logged in
        $_SESSION['log']=true;
        echo'logged in';
    }else{
        // Display an error message if the email or password is incorrect
        echo 'something is wrong with email or password';
    };
}

// Display a 'back' button that links to the index.php page
echo '<button><a href="index.php">back</a></button>'
?>
</main>
</html>
